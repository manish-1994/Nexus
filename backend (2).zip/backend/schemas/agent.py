from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any

class AgentBase(BaseModel):
    name: str
    description: Optional[str] = None
    icon: Optional[str] = "bot"
    color: Optional[str] = None
    category: Optional[str] = None
    provider_id: Optional[int] = None
    model: Optional[str] = None
    temperature: float = 0.7
    top_p: float = 1.0
    max_tokens: Optional[int] = None
    context_window: Optional[int] = None
    streaming: bool = True
    enabled: bool = True
    prompt_template: Optional[str] = None
    capabilities: Optional[str] = "[]"
    tools: Optional[str] = "[]"
    default_tools: Optional[str] = "[]"
    memory_enabled: bool = False

class AgentCreate(AgentBase):
    pass

class AgentUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    icon: Optional[str] = None
    color: Optional[str] = None
    category: Optional[str] = None
    provider_id: Optional[int] = None
    model: Optional[str] = None
    temperature: Optional[float] = None
    top_p: Optional[float] = None
    max_tokens: Optional[int] = None
    context_window: Optional[int] = None
    streaming: Optional[bool] = None
    enabled: Optional[bool] = None
    prompt_template: Optional[str] = None
    capabilities: Optional[str] = None
    tools: Optional[str] = None
    default_tools: Optional[str] = None
    memory_enabled: Optional[bool] = None

class AgentResponse(AgentBase):
    id: int

    class Config:
        orm_mode = True
