from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from database import get_db
from models.agent import Agent
from schemas.agent import AgentCreate, AgentUpdate, AgentResponse
from agents.manager import AgentManager
import logging

router = APIRouter()
logger = logging.getLogger("agents")

@router.get("/agents", response_model=List[AgentResponse])
async def list_agents(db: Session = Depends(get_db)):
    """List all agents."""
    return db.query(Agent).all()

@router.get("/agents/{agent_id}", response_model=AgentResponse)
async def get_agent(agent_id: int, db: Session = Depends(get_db)):
    """Get a specific agent."""
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return agent

@router.post("/agents", response_model=AgentResponse, status_code=201)
async def create_agent(agent_in: AgentCreate, db: Session = Depends(get_db)):
    """Create a new agent."""
    agent = Agent(**agent_in.dict())
    db.add(agent)
    db.commit()
    db.refresh(agent)
    return agent

@router.patch("/agents/{agent_id}", response_model=AgentResponse)
async def update_agent(agent_id: int, agent_in: AgentUpdate, db: Session = Depends(get_db)):
    """Update an agent."""
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    
    update_data = agent_in.dict(exclude_unset=True)
    for key, value in update_data.items():
        setattr(agent, key, value)
        
    db.commit()
    db.refresh(agent)
    return agent

@router.delete("/agents/{agent_id}", status_code=204)
async def delete_agent(agent_id: int, db: Session = Depends(get_db)):
    """Delete an agent."""
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
        
    db.delete(agent)
    db.commit()
    return None

from pydantic import BaseModel

class AgentTestRequest(BaseModel):
    message: str = "Hello, this is a test."

@router.post("/agents/{agent_id}/test")
async def test_agent(agent_id: int, request: AgentTestRequest, db: Session = Depends(get_db)):
    """Test agent configuration and execution."""
    import time
    from services.ai_runtime import AIRuntime
    try:
        manager = AgentManager(db)
        agent_config = manager.get_agent_config(agent_id)
        
        provider_id = agent_config.get("provider_id")
        model = agent_config.get("model")
        if not provider_id or not model:
            raise ValueError("Agent must have a default provider and model to be tested directly.")
            
        manager.validate_execution(provider_id, model)
        
        # Build prompt
        messages = [{"role": "user", "content": request.message}]
        messages = manager.build_prompt_for_agent(agent_id, messages)
        
        runtime = AIRuntime(db)
        
        start_time = time.time()
        response_text = runtime.chat(messages=messages, provider_id=provider_id, model=model)
        latency_ms = int((time.time() - start_time) * 1000)
        
        return {
            "status": "success", 
            "response": response_text,
            "latency_ms": latency_ms,
            "provider_id": provider_id,
            "model": model,
            # We don't have token usage from AIRuntime.chat yet in this version, so mock or omit
            "tokens_used": None,
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.exception("Agent test failed")
        raise HTTPException(status_code=500, detail=str(e))

__all__ = ["router"]
